package com.lead.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lead.entity.User;

/**
 * @author mac
 */
public interface UserDao extends BaseMapper<User> {
}
